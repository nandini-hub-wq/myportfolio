NANDINI DAHARWAL - 3D PORTFOLIO (no install needed)

HOW TO RUN
1. Unzip this folder.
2. Easiest: double-click index.html (opens in Chrome/Edge).
   In VS Code: File > Open Folder > choose this folder > right-click index.html > "Open with Live Server"
   (install the free "Live Server" extension once) or just open index.html in your browser.
3. You need internet once per visit: the 3D library (three.js) and fonts load from a CDN. Everything else is in this folder.

HOW TO EDIT
- Open index.html in VS Code. Text/content is near the top inside the <script> (sections SEC, SAY, P, F).
- Photos and certificates: assets/images. Resume PDF: assets/resume.
- Avatar's narration: the SAY object.
- Add project links: inside the Projects section, add a line like lk('https://github.com/...','GitHub').

NOTES
- Voice narration uses your browser's free voices; it starts only after you click START THE TOUR. Use the Mute button if needed.
- Certificate IDs and QR codes are already hidden in the images.
- Contact form opens your email app (mailto); it never claims a message was sent.
